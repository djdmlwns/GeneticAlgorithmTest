# Feedback and Improvements

This folder serves as a platform for readers to suggest changes, improvements and variations of the original code.

These suggestions may be incorporated into future editions of this book.

Each folder underneath this one starts as a copy of the original corresponding folder, and readers are invited to submit PRs against its files.
